import { useState, useRef, useEffect } from "react";
import { useAuth } from "@clerk/clerk-react";
import {
  useListDocuments,
  useUploadDocument,
  useDeleteDocument,
  getListDocumentsQueryKey,
  getGetCaseReadinessQueryKey,
  getListCasesQueryKey,
  getGetCaseStatsQueryKey,
  getGetCaseQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { FileText, Paperclip, Trash2, Eye, ClipboardList, CheckSquare2, Square, AlertCircle } from "lucide-react";
import { i18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

// ─── DocTile ─────────────────────────────────────────────────────────────────
function DocTile({ doc, caseId, onDelete, deleting, getToken, onSaved }: {
  doc: any;
  caseId: number;
  onDelete: () => void;
  deleting: boolean;
  getToken: () => Promise<string | null>;
  onSaved: () => void;
}) {
  const [label] = useState(doc.label || doc.filename || "");
  const [description, setDescription] = useState(doc.description || "");
  const [saving, setSaving] = useState(false);
  const [viewing, setViewing] = useState(false);

  const save = async (nextDesc: string) => {
    if (nextDesc === (doc.description || "")) return;
    setSaving(true);
    try {
      const token = await getToken();
      await fetch(`/api/cases/${caseId}/documents/${doc.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ label, description: nextDesc }),
      });
      onSaved();
    } catch { /* silent */ }
    setSaving(false);
  };

  const handleView = async () => {
    if (viewing) return;
    setViewing(true);
    try {
      const token = await getToken();
      const res = await fetch(`/api/cases/${caseId}/documents/${doc.id}/file`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error("Failed to load document");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
    } catch { /* silent */ }
    setViewing(false);
  };

  return (
    <div className="flex items-center gap-3 rounded-xl border bg-card px-4 py-3 shadow-sm">
      <div className="shrink-0 h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
        <FileText className="h-4 w-4 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="flex-1 min-w-0 text-sm font-medium truncate">{label}</p>
          {saving && <span className="text-[10px] text-muted-foreground shrink-0">saving…</span>}
        </div>
        <input
          className="w-full text-xs text-foreground/60 bg-transparent border-b border-transparent hover:border-muted-foreground/40 focus:border-primary/60 focus:outline-none transition-colors mt-0.5 placeholder:text-foreground/40"
          value={description}
          onChange={e => setDescription(e.target.value)}
          onBlur={() => save(description)}
          onKeyDown={e => { if (e.key === "Enter") e.currentTarget.blur(); }}
          maxLength={80}
          placeholder="Add a note…"
        />
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-muted-foreground hover:text-primary"
          onClick={handleView}
          disabled={viewing}
          aria-label="View document"
          title="View document"
        >
          <Eye className={`h-4 w-4 ${viewing ? "animate-pulse" : ""}`} />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={onDelete} disabled={deleting} aria-label="Delete document">
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

// ─── Main Tab ────────────────────────────────────────────────────────────────
export function DocumentsTab({ caseId, evidenceChecklist }: { caseId: number; evidenceChecklist: { id: string; item: string; description: string; checked?: boolean }[] }) {
  const { data: documents } = useListDocuments(caseId, { query: { enabled: !!caseId } });
  const uploadDoc = useUploadDocument();
  const deleteDoc = useDeleteDocument();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { getToken } = useAuth();

  const [activeTab, setActiveTab] = useState<"checklist" | "uploads">("checklist");

  const [checkedItems, setCheckedItems] = useState<Set<string>>(
    () => new Set(evidenceChecklist.filter(i => i.checked).map(i => i.id))
  );

  useEffect(() => {
    setCheckedItems(new Set(evidenceChecklist.filter(i => i.checked).map(i => i.id)));
  }, [evidenceChecklist]);

  const saveChecked = async (next: Set<string>) => {
    try {
      const token = await getToken();
      await fetch(`/api/cases/${caseId}/advisor/checklist`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ checkedIds: Array.from(next) }),
      });
      queryClient.invalidateQueries({ queryKey: getGetCaseQueryKey(caseId) });
    } catch { /* silent */ }
  };

  const toggleItem = (id: string) => {
    setCheckedItems(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      saveChecked(n);
      return n;
    });
  };

  const deleteChecklistItem = async (itemId: string) => {
    try {
      const token = await getToken();
      await fetch(`/api/cases/${caseId}/advisor/checklist/${itemId}`, {
        method: "DELETE",
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      queryClient.invalidateQueries({ queryKey: getGetCaseQueryKey(caseId) });
    } catch { /* silent */ }
  };

  const invalidateDocAndScore = () => {
    queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey(caseId) });
    queryClient.invalidateQueries({ queryKey: getGetCaseReadinessQueryKey(caseId) });
    queryClient.invalidateQueries({ queryKey: getListCasesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetCaseStatsQueryKey() });
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    const file = e.target.files[0];
    e.target.value = "";
    try {
      await uploadDoc.mutateAsync({ id: caseId, data: { file, label: file.name } });
      invalidateDocAndScore();
      toast({ title: "Document uploaded", description: "OCR text extraction is running in the background." });
      setActiveTab("uploads");
    } catch (err: any) {
      const msg = err?.data?.error ?? err?.message ?? "Upload failed — please try again.";
      toast({ title: "Upload failed", description: msg, variant: "destructive" });
    }
  };

  const handleDelete = (docId: number) => {
    deleteDoc.mutate({ id: caseId, docId }, { onSuccess: () => { invalidateDocAndScore(); } });
  };

  const uploadCount = documents?.length ?? 0;
  const checklistCount = evidenceChecklist.length;

  return (
    <div className="p-6 md:p-8">
      {/* Sub-tabs + Upload button — same row */}
      <div className="flex items-center gap-6 mb-6">
        <input type="file" ref={fileInputRef} className="hidden" accept=".pdf,.jpg,.jpeg,.png,.docx" onChange={handleUpload} />
        <button
          type="button"
          onClick={() => setActiveTab("checklist")}
          className={`flex flex-1 items-center gap-3 px-6 py-3 rounded-xl text-sm font-semibold transition-all border-2 shadow-sm justify-center ${
            activeTab === "checklist"
              ? "bg-[#f0fffe] text-[#0d6b5e] border-[#0d6b5e] shadow-[#0d6b5e]/20 shadow-md"
              : "bg-background text-muted-foreground border-muted-foreground/25 hover:border-[#0d6b5e]/50 hover:text-[#0d6b5e] hover:bg-[#f0fffe]/50"
          }`}
        >
          <ClipboardList className="h-6 w-6 shrink-0" />
          <span>
            <span className={`block text-[10px] font-medium uppercase tracking-wider mb-0.5 ${activeTab === "checklist" ? "text-[#0d6b5e]" : "text-muted-foreground/60"}`}>Click here</span>
            Document Checklist
          </span>
          {checklistCount > 0 && (
            <span className={`ml-auto text-[11px] rounded-full px-1.5 py-0.5 font-semibold ${
              activeTab === "checklist" ? "bg-[#0d6b5e]/15 text-[#0d6b5e]" : "bg-muted text-muted-foreground"
            }`}>
              {checkedItems.size}/{checklistCount}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("uploads")}
          className={`flex flex-1 items-center gap-3 px-6 py-3 rounded-xl text-sm font-semibold transition-all border-2 shadow-sm justify-center ${
            activeTab === "uploads"
              ? "bg-[#f0fffe] text-[#0d6b5e] border-[#0d6b5e] shadow-[#0d6b5e]/20 shadow-md"
              : "bg-background text-muted-foreground border-muted-foreground/25 hover:border-[#0d6b5e]/50 hover:text-[#0d6b5e] hover:bg-[#f0fffe]/50"
          }`}
        >
          <FileText className="h-6 w-6 shrink-0" />
          <span>
            <span className={`block text-[10px] font-medium uppercase tracking-wider mb-0.5 ${activeTab === "uploads" ? "text-[#0d6b5e]" : "text-muted-foreground/60"}`}>Click here</span>
            My Uploads
          </span>
          {uploadCount > 0 && (
            <span className={`ml-auto text-[11px] rounded-full px-1.5 py-0.5 font-semibold ${
              activeTab === "uploads" ? "bg-[#0d6b5e]/15 text-[#0d6b5e]" : "bg-muted text-muted-foreground"
            }`}>
              {uploadCount}
            </span>
          )}
        </button>
        <Button className="ml-auto shrink-0" onClick={() => fileInputRef.current?.click()} disabled={uploadDoc.isPending} data-testid="button-upload-doc">
          <Paperclip className="h-4 w-4 mr-2" />
          {uploadDoc.isPending ? i18n.documents.processing : i18n.documents.uploadBtn}
        </Button>
      </div>

      {/* ── Checklist Tab ── */}
      {activeTab === "checklist" && (
        <div>
          {evidenceChecklist.length === 0 ? (
            <div className="rounded-xl border border-dashed border-muted-foreground/25 bg-muted/10 p-8 text-center">
              <ClipboardList className="h-8 w-8 text-muted-foreground/40 mx-auto mb-3" />
              <p className="font-semibold text-sm text-foreground">No checklist yet</p>
              <p className="text-xs text-muted-foreground mt-1">Ask the AI Genie to analyze your case and it will generate a document checklist for you.</p>
            </div>
          ) : (
            <div className="rounded-lg border border-[#a8e6df] bg-[#f0fffe] p-4">
              <div className="flex items-center gap-2 mb-1">
                <ClipboardList className="h-4 w-4 text-[#0d6b5e]" />
                <h3 className="font-semibold text-sm text-[#0d6b5e]">Your Document Checklist</h3>
                <span className="text-xs text-muted-foreground ml-auto">{checkedItems.size}/{evidenceChecklist.length} gathered</span>
              </div>
              <p className="text-xs text-muted-foreground mb-3">Check off each document as you gather it, then upload it using the button above.</p>
              <div className="space-y-2">
                {evidenceChecklist.map((item) => (
                  <div key={item.id} className="flex items-start gap-2 rounded-lg border border-[#a8e6df] bg-white p-3">
                    <button type="button" onClick={() => toggleItem(item.id)} className="flex items-start gap-3 flex-1 text-left hover:bg-[#ddf6f3]/40 transition-colors rounded">
                      <div className="mt-0.5 shrink-0 text-[#0d6b5e]">
                        {checkedItems.has(item.id) ? <CheckSquare2 className="h-5 w-5" /> : <Square className="h-5 w-5 text-muted-foreground" />}
                      </div>
                      <div>
                        <p className={`text-sm font-medium ${checkedItems.has(item.id) ? "line-through text-muted-foreground" : ""}`}>{item.item}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>
                      </div>
                    </button>
                    <button type="button" onClick={() => deleteChecklistItem(item.id)} className="shrink-0 p-1 rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors" aria-label="Remove from checklist">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Uploads Tab ── */}
      {activeTab === "uploads" && (
        <div>
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 mb-4 flex items-start gap-3">
            <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-sm text-amber-800">
              <span className="font-semibold">Don't forget:</span> Upload any documents, photos, screenshots, or images relevant to your case — even if they're not on the checklist.
            </p>
          </div>

          <div
            className="border-2 border-dashed border-muted-foreground/25 rounded-lg px-5 py-4 mb-6 bg-muted/5 cursor-pointer hover:border-primary/40 transition-colors flex items-center gap-4"
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="shrink-0 w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center">
              <FileText className="h-5 w-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm">Drag and drop files here</p>
              <p className="text-xs text-muted-foreground">Contracts, receipts, photos, texts, emails, invoices — anything related to your case</p>
            </div>
            <Button variant="outline" type="button" className="shrink-0" onClick={e => { e.stopPropagation(); fileInputRef.current?.click(); }}>Browse Files</Button>
          </div>

          <div className="space-y-3">
            {documents?.map((doc: any) => (
              <DocTile
                key={doc.id}
                doc={doc}
                caseId={caseId}
                onDelete={() => handleDelete(doc.id)}
                deleting={deleteDoc.isPending}
                getToken={getToken}
                onSaved={invalidateDocAndScore}
              />
            ))}
            {(!documents || documents.length === 0) && (
              <div className="rounded-xl border border-dashed border-muted-foreground/25 bg-muted/10 p-6 mt-2">
                <div className="flex flex-col items-center gap-3 text-center mb-5">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <FileText className="h-6 w-6 text-primary/60" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-sm">No documents uploaded yet</p>
                    <p className="text-xs text-muted-foreground mt-1 leading-relaxed">The AI Genie reads your documents and uses them to answer questions. Upload everything you have — more is better.</p>
                  </div>
                </div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 text-center">Documents that win small claims cases</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { icon: "📄", label: "Contracts & agreements", sub: "Written or signed" },
                    { icon: "🧾", label: "Receipts & invoices", sub: "Proof of payment" },
                    { icon: "📷", label: "Photos & videos", sub: "Damage or condition" },
                    { icon: "💬", label: "Texts & emails", sub: "Screenshots work" },
                    { icon: "🏦", label: "Bank statements", sub: "Transfers & charges" },
                    { icon: "📬", label: "Prior demand letters", sub: "If you sent one" },
                  ].map(({ icon, label, sub }) => (
                    <button
                      key={label}
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-start gap-2.5 rounded-lg border border-border bg-background hover:border-primary/40 hover:bg-primary/5 px-3 py-2.5 text-left transition-colors"
                    >
                      <span className="text-lg shrink-0 mt-0.5">{icon}</span>
                      <div>
                        <p className="text-[12px] font-medium text-foreground leading-tight">{label}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5">{sub}</p>
                      </div>
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground text-center mt-4">Click any card or use the Browse Files button above — PDFs, images, and Word docs all accepted</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
