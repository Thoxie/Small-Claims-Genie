# SC-112A AcroForm packet

This packet contains a working AcroForm version of California Judicial Council Form SC-112A, Proof of Service by Mail (Small Claims), plus a field map and sample fill values.

Files:

- `SC-112A_AcroForm_Blank_Unlocked.pdf` - unencrypted, fillable AcroForm template.
- `SC-112A_AcroForm_Sample_Filled.pdf` - sample-filled AcroForm generated from the sample JSON.
- `sc112a_acroform_field_map.json` - logical Small Claims Genie field names mapped to the actual PDF AcroForm field names.
- `sc112a_sample_values_official_names.json` - sample fill payload using official AcroForm field names.
- `sc112a_form_model.ts` - suggested TypeScript data model, field constants, and validation helper.

Important implementation notes:

- Checkbox on-value is `/1`; off-value is `/Off`.
- The template has a printed signature line, but no separate AcroForm field for the actual server signature.
- Page 2 is the instruction page. It says it is not part of the Proof of Service and does not need to be copied, served, or filed.
- SC-112A cannot be used to prove service of SC-100 or SC-120. Route those to SC-104/SC-104B.
- The server must be 18 or older, must not be a party, and must live or work in the county where mailing occurs.

Suggested app behavior:

1. Collect the logical form model in the UI.
2. Validate the form using the required fields and SC-112A eligibility rules.
3. Convert the logical model to official AcroForm field names using `sc112a_acroform_field_map.json` or `SC112A_FIELD_MAP`.
4. Fill the PDF.
5. For court output, consider flattening after filling if your PDF pipeline supports reliable appearance generation.
