// Path: /app/_config/routes.js
export const ROUTES = {
  home: "/",
  howItWorks: "/how-it-works",

  // Static pages
  typesOfCases: "/types-of-cases",
  faq: "/faq",

  start: "/start",
  dashboard: "/case-dashboard",

  intake: "/intake-wizard",
  documents: "/documents",
  preview: "/document-preview",
  filingGuidance: "/filing-guidance",
  keyDates: "/key-dates",

  drafts: "/drafts",
  draftPreview: "/draft-preview",

  aiChat: "/ai-chatbox",

  // New: user-facing instruction videos + tips
  resources: "/resources"
};
